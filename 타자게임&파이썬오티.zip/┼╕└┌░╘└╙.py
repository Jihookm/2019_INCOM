import random
import time

h=["수요일마다 인컴 수요모임에서 놀아요",
   "화요일마다 컴퓨터 교육 받으러 오세요",
   "목요일마다 목요미식회와 목요무비데이가 있어요",
   "인커미들끼리 게임대회를 열어요",
   "선배들이 주는 족보 받아봐요",
   "엠티도 가고 체육대회도 즐겨봐요"]

NumOfQ1=1

print("\n[INCOM 타자 게임]")
print("\n인컴 운영진보다 빨리 클리어하세요 !")


a=input("\n\n당신의 이름은? : ")
print("\n★★★★★★★★★★★★INCOM★★★★★★★★★★★★★★★")
print(" [Lv.1] 다음 문장을 그대로 따라 적어주세요!(6문제)")
print("★★★★★★★★★★★★INCOM★★★★★★★★★★★★★★★")
print("Enter 누르면 시작 !")
input()
start=time.time()

q=random.choice(h)
while NumOfQ1<=5:
    print("[문제",NumOfQ1,"]")
    print(q)
 #   print("\n")
    x=input()
    if q==x:
        print("GOOD\n")
        NumOfQ1=NumOfQ1+1
        q=random.choice(h)
    else:
        print("FAIL! TRY AGAIN!\n")
end=time.time()
et=end-start
et=format(et,".2f")

print("★★★★★★★★★★★★INCOM★★★★★★★★★★★★★★★")
print(a,"님이 걸린 시간 : ",et,"초")
print("★★★★★★★★★★★★INCOM★★★★★★★★★★★★★★★")
